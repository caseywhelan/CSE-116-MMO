from flask import Flask, jsonify
from flask import request
from datetime import datetime
import re
import json
from flask import render_template
#from flask_cors import CORS


app = Flask(__name__)

#@app.route('/')
#def index():


@app.route('/')
def start():
    return render_template('index.html')


@app.route('/getCooking', methods=['POST'])
def add_user():
    req_data = request.get_json()
    username = req_data['username']
    list = []
    f = open('usernames', 'w+')
    for user in username:
        f.write(user + "\n")
        list.append(user)
    f.close()

    return str(list).strip('[]')


@app.route('/exitKitchen', methods=['POST'])
def leave_game():
    req_data = request.get_json()
    username = req_data['username']
    with open("usernames", "r+") as f:
        d = f.readlines()
        f.seek(0)
        for user in username:
            for i in d:
                if user in i:
                    f.write(i)
        f.truncate()

    return "Player has left game"


@app.route('/chefs', methods=['GET'])
def get_cooks():
    # f = open('usernames', 'r+')
    data = request.data
    dataDict = json.loads(data)
    list = []
    for user in dataDict.values():

        list.append(user)
    return str(list).strip("[]")



if __name__ == '__main__':
    app.run(debug=True, port=5000)